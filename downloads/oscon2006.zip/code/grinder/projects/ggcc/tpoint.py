# The Grinder 3.0-beta30
# HTTP script recorded by TCPProxy at Jun 23, 2006 4:01:19 PM

from net.grinder.script import Test
from net.grinder.script.Grinder import grinder
from net.grinder.plugin.http import HTTPPluginControl, HTTPRequest
from HTTPClient import NVPair
connectionDefaults = HTTPPluginControl.getConnectionDefaults()
httpUtilities = HTTPPluginControl.getHTTPUtilities()

# To use a proxy server, uncomment the next line and set the host and port.
# connectionDefaults.setProxyServer("localhost", 8001)

# These definitions at the top level of the file are evaluated once,
# when the worker process is started.

connectionDefaults.defaultHeaders = \
  ( NVPair('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.0.4) Gecko/20060508 Firefox/1.5.0.4'),
    NVPair('Accept-Encoding', 'gzip,deflate'),
    NVPair('Accept-Language', 'en-us,en;q=0.5'),
    NVPair('Accept-Charset', 'ISO-8859-1,utf-8;q=0.7,*;q=0.7'),
    NVPair('Cache-Control', 'no-cache'), )

headers0= \
  ( NVPair('Accept', 'image/png,*/*;q=0.5'), )

headers1= \
  ( NVPair('Accept', 'text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'), )

headers2= \
  ( NVPair('Accept', 'text/css,*/*;q=0.1'), )

headers3= \
  ( NVPair('Accept', 'image/png,*/*;q=0.5'), )

headers4= \
  ( NVPair('Accept', 'text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'),
    NVPair('Referer', 'http://www.transitionpoint.com/'), )

headers5= \
  ( NVPair('Accept', 'text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'),
    NVPair('Referer', 'http://www.transitionpoint.com/index.html'), )

headers6= \
  ( NVPair('Accept', 'text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'),
    NVPair('Referer', 'http://www.transitionpoint.com/aboutus.html'), )

headers7= \
  ( NVPair('Accept', 'text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'),
    NVPair('Referer', 'http://www.transitionpoint.com/services.html'), )

headers8= \
  ( NVPair('Accept', 'text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'),
    NVPair('Referer', 'http://www.transitionpoint.com/clients.html'), )

url0 = 'http://sourceforge.net:80'
url1 = 'http://www.transitionpoint.com:80'

# Create an HTTPRequest for each request, then replace the
# reference to the HTTPRequest with an instrumented version.
# You can access the unadorned instance using request101.__target__.
request101 = HTTPRequest(url=url0, headers=headers0)
request101 = Test(101, 'GET sflogo.php').wrap(request101)

request201 = HTTPRequest(url=url1, headers=headers1)
request201 = Test(201, 'GET /').wrap(request201)

request202 = HTTPRequest(url=url1, headers=headers2)
request202 = Test(202, 'GET web.css').wrap(request202)

request203 = HTTPRequest(url=url1, headers=headers2)
request203 = Test(203, 'GET print.css').wrap(request203)

request204 = HTTPRequest(url=url1, headers=headers3)
request204 = Test(204, 'GET tp_logo.gif').wrap(request204)

request301 = HTTPRequest(url=url1, headers=headers4)
request301 = Test(301, 'GET index.html').wrap(request301)

request401 = HTTPRequest(url=url1, headers=headers5)
request401 = Test(401, 'GET aboutus.html').wrap(request401)

request501 = HTTPRequest(url=url1, headers=headers6)
request501 = Test(501, 'GET services.html').wrap(request501)

request601 = HTTPRequest(url=url1, headers=headers7)
request601 = Test(601, 'GET clients.html').wrap(request601)

request602 = HTTPRequest(url=url1, headers=headers3)
request602 = Test(602, 'GET boomerang_logo.jpg').wrap(request602)

request603 = HTTPRequest(url=url1, headers=headers3)
request603 = Test(603, 'GET boxer_logo.gif').wrap(request603)

request604 = HTTPRequest(url=url1, headers=headers3)
request604 = Test(604, 'GET wr_logo.gif').wrap(request604)

request605 = HTTPRequest(url=url1, headers=headers3)
request605 = Test(605, 'GET ta_logo.jpg').wrap(request605)

request701 = HTTPRequest(url=url1, headers=headers8)
request701 = Test(701, 'GET contact.html').wrap(request701)


class TestRunner:
  """A TestRunner instance is created for each worker thread."""

  # A method for each recorded page.
  def page1(self):
    """GET sflogo.php (request 101)."""
    self.token_group_id = \
      '18598'
    result = request101.GET('/sflogo.php' +
      '?group_id=' +
      self.token_group_id)

    return result

  def page2(self):
    """GET / (requests 201-204)."""
    result = request201.GET('/')

    grinder.sleep(62)
    request202.GET('/css/web.css')

    grinder.sleep(31)
    request203.GET('/css/print.css')

    grinder.sleep(32)
    request204.GET('/images/tp_logo.gif')

    return result

  def page3(self):
    """GET index.html (request 301)."""
    result = request301.GET('/index.html')

    return result

  def page4(self):
    """GET aboutus.html (request 401)."""
    result = request401.GET('/aboutus.html')

    return result

  def page5(self):
    """GET services.html (request 501)."""
    result = request501.GET('/services.html')

    return result

  def page6(self):
    """GET clients.html (requests 601-605)."""
    result = request601.GET('/clients.html')

    grinder.sleep(140)
    request602.GET('/images/boomerang_logo.jpg')

    request603.GET('/images/boxer_logo.gif')

    grinder.sleep(15)
    request604.GET('/images/wr_logo.gif')

    request605.GET('/images/ta_logo.jpg')

    return result

  def page7(self):
    """GET contact.html (request 701)."""
    result = request701.GET('/contact.html')

    return result

  def __call__(self):
    """This method is called for every run performed by the worker thread."""
    self.page1()      # GET sflogo.php (request 101)

    grinder.sleep(14250)
    self.page2()      # GET / (requests 201-204)

    grinder.sleep(2375)
    self.page3()      # GET index.html (request 301)

    grinder.sleep(1890)
    self.page4()      # GET aboutus.html (request 401)

    grinder.sleep(1266)
    self.page5()      # GET services.html (request 501)

    grinder.sleep(969)
    self.page6()      # GET clients.html (requests 601-605)

    grinder.sleep(1016)
    self.page7()      # GET contact.html (request 701)


def instrumentMethod(test, method_name, c=TestRunner):
  """Instrument a method with the given Test."""
  unadorned = getattr(c, method_name)
  import new
  method = new.instancemethod(test.wrap(unadorned), None, c)
  setattr(c, method_name, method)

# Replace each method with an instrumented version.
# You can call the unadorned method using self.page1.__target__().
instrumentMethod(Test(100, 'Page 1'), 'page1')
instrumentMethod(Test(200, 'Page 2'), 'page2')
instrumentMethod(Test(300, 'Page 3'), 'page3')
instrumentMethod(Test(400, 'Page 4'), 'page4')
instrumentMethod(Test(500, 'Page 5'), 'page5')
instrumentMethod(Test(600, 'Page 6'), 'page6')
instrumentMethod(Test(700, 'Page 7'), 'page7')
