
        <div class="clear"></div>
    </div>
    <!-- End of content part -->
    <!-- Begin of footer -->
    <div class="footer">
    	<div class="footer_left">
        <div class="footer_right">
        	<div class="footer_inner">
            <!-- PLEASE feel free to edit the theme as much as you like, but keep this links in your footer. Thanks You! :) -->
            	<div class="float-left">&copy; 2009 <?php bloginfo('name'); ?> | Theme designed by: <a href="http://www.getacustomdesign.com">Get a custom design</a></div>
                <div class="float-right">Powered by: <a href="http://wordpress.org">Wordpress</a></div>
            </div>
        </div>
        </div>
        
    </div>
    <!-- End of footer -->
</div>
<?php wp_footer(); ?>
</body>
</html>
