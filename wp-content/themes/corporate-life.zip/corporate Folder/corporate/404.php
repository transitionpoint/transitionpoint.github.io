<?php get_header();?>
<div class="content">
<div class="mainbar">
    <div class="page"> 
         <div class="page_entry">
            <h2>404 page not found</h2>
            <p>Sorry, but you are looking for something that isn't here.</p>
         </div>
     </div>
</div> 
<?php get_sidebar(); ?>

<?php get_footer(); ?>